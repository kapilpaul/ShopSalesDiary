# ShopSalesDiary

This application is made for learning purpose. Please help me to learn more.
