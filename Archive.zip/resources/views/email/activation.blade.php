<h1>Hello</h1>


<p>
    Please activate your account by click <a href="{{env('APP_URL')}}/activation/{{$user->email}}/{{$code}}">here</a>
</p>