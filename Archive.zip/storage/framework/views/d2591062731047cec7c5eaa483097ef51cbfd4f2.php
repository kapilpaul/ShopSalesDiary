<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>User Create</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">User profile</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">All Users</h3>

                            <div class="box-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                                    <div class="input-group-btn">
                                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">

                            <?php if(session('error')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e(session('error')); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            <?php endif; ?>

                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Last Login</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php if($users): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->roles->first()->name); ?></td>
                                        <td>
                                            <?php if(Activation::completed($user)): ?>
                                                <span class="label label-success">Active</span>
                                            <?php else: ?>
                                                <span class="label label-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($user->last_login): ?>
                                                <?php echo e(\Carbon\Carbon::parse($user->last_login)->diffForHumans()); ?>

                                            <?php else: ?>
                                                Not Logged in Yet
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(Activation::completed($user)): ?>
                                                <?php echo Form::model($user, ['method' => 'POST', 'class' =>'pull-left', 'action' => ['AdminUserController@inactive', $user->id]]); ?>

                                                <?php echo Form::submit('InActive', ['class'=>'btn btn-danger btn-sm']); ?>


                                                <?php echo Form::close(); ?>

                                            <?php else: ?>
                                                <?php echo Form::model($user, ['method' => 'POST', 'class' =>'pull-left', 'action' => ['AdminUserController@active', $user->id]]); ?>

                                                <?php echo Form::submit('Active', ['class'=>'btn btn-success btn-sm']); ?>


                                                <?php echo Form::close(); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['AdminUserController@destroy', $user->id]]); ?>

                                                <?php echo Form::submit('Delete', ['class'=>'btn btn-danger btn-sm', 'onclick' => 'alert("are You sure to delete")']); ?>

                                            <?php echo Form::close(); ?>



                                        </td>

                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($users->links('layouts.pagination')); ?>

                        <?php endif; ?>
                    </div>
                    <!-- /.box -->
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>