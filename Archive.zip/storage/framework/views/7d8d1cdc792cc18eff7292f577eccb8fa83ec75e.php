<?php $__env->startSection('title'); ?>
    Expenses
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Expenses</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Expenses</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- /.box-header -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    <?php endif; ?> <?php if(session('error')): ?>
                        <div class="alert alert-error">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="box box-primary collapsed-box">
                        <div class="box-header with-border" data-widget="collapse">
                            <h3 class="box-title">Add Expenses</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool"><i class="fa fa-plus"></i>
                                </button>
                            </div>
                            <!-- /.box-tools -->
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <?php echo Form::open(['method' => 'POST', 'action' => 'ExpenseController@store', 'class' => '']); ?>

                            <div class="box-body">
                                <div class="form-group has-feedback">
                                    <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder' => 'Expense Name']); ?>

                                    <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('name', 'Expense Name Required')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group has-feedback">
                                    <?php echo Form::text('amount', null, ['class'=>'form-control', 'placeholder' => 'Expense Amount']); ?>


                                    <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                    <?php if($errors->has('amount')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('amount', 'Expense Amount Required')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group has-feedback">
                                    <?php echo Form::date('date', Carbon\Carbon::now(), ['class'=>'form-control']); ?>


                                    <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                    <?php if($errors->has('date')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('date')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="box-footer">
                                <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                                <?php echo Form::submit('Add Expense', ['class'=>'btn btn-info pull-right']); ?>

                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title pull-left">All Expenses</h3>

                        </div>

                        <?php if(session('exp_success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('exp_success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($expenses): ?>
                        <!-- /.box-header -->

                            <div class="box-body no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px"></th>
                                        <th style="width: 10px">#</th>
                                        <th>Expense Name</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr>
                                            <td></td>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($expense->name); ?></td>
                                            <td><?php echo e($expense->amount); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($expense->date)->format('d-M-Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p>
                                                </a>
                                            </td>

                                            <td>
                                                <a href="<?php echo e(url('expenses/deleteall', $expense->id)); ?>">

                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                        <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                            <span class="glyphicon glyphicon-trash"></span>
                                                        </button>
                                                    </p>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($expenses->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>