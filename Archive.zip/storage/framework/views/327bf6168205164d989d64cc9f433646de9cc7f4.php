<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>User Create</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Category</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add Category</h3>
                        </div>
                        <!-- /.box-header -->


                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="box-body">
                                <div class="alert alert-error">
                                    <p><?php echo e(session('error')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo Form::model($category, ['method' => 'PATCH', 'action' => ['CategoryController@update', $category->id], 'class' => '']); ?>

                        <div class="box-body">
                            <div class="form-group has-feedback">
                                <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder' => 'Category Name']); ?>


                                <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('name', 'Category Name Required')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="box-footer">
                            <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                            <?php echo Form::submit('Update Category', ['class'=>'btn btn-info pull-right']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>