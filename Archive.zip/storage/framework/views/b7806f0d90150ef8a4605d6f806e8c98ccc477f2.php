<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(env('APP_URL')); ?>/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p> <?php if(Sentinel::check()): ?>
                        <?php echo e(Sentinel::getUser()->name); ?>

                    <?php else: ?>
                        Alex
                    <?php endif; ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- search form -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
                    <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                      <i class="fa fa-search"></i>
                    </button>
                  </span>
            </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>

            <?php if(\Cartalyst\Sentinel\Laravel\Facades\Sentinel::check() && \Cartalyst\Sentinel\Laravel\Facades\Sentinel::getUser()->roles()->first()->slug == 'admin'): ?>
            <li class="<?php echo e(isActiveRoute('home')); ?>">
                <a href="<?php echo e(route('home')); ?>"> <i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
            </li>
            <li class="<?php echo e(isActiveRoute('category.index')); ?>">
                <a href="<?php echo e(route('category.index')); ?>"> <i class="fa fa-dashboard"></i> <span>Category</span></a>
            </li>
            <li class="<?php echo e(isActiveRoute('brands.index')); ?>">
                <a href="<?php echo e(route('brands.index')); ?>"> <i class="fa fa-dashboard"></i> <span>Brands</span></a>
            </li>
            <li class="treeview <?php echo e(areActiveRoutes(['products.create', 'products.index', ])); ?>">
                <a href="#">
                    <i class="fa fa-edit"></i> <span>Products</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(isActiveRoute('products.create')); ?>"><a href="<?php echo e(route('products.create')); ?>"><i class="fa fa-circle-o"></i> New</a></li>
                    <li class="<?php echo e(isActiveRoute('products.index')); ?>"><a href="<?php echo e(route('products.index')); ?>"><i class="fa fa-circle-o"></i> View</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(areActiveRoutes(['stocks.index', 'stocks.create', 'availableStock'])); ?>">
                <a href="#">
                    <i class="fa fa-files-o"></i>
                    <span>Stocks</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(isActiveRoute('stocks.create')); ?>"><a href="<?php echo e(route('stocks.create')); ?>"><i class="fa fa-circle-o"></i> New</a></li>
                    <li class="<?php echo e(isActiveRoute('stocks.index')); ?>"><a href="<?php echo e(route('stocks.index')); ?>"><i class="fa fa-circle-o"></i> View</a></li>
                    <li class="<?php echo e(isActiveRoute('availableStock')); ?>"><a href="<?php echo e(route('availableStock')); ?>"><i class="fa fa-circle-o"></i> Available Stocks</a></li>
                </ul>
            </li>

            <li class="treeview <?php echo e(areActiveRoutes(['sells.search', 'sells.index', 'currentmonth.sell', 'searchMonthRange.sell'])); ?>">
                <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span>Sells</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(isActiveRoute('sells.search')); ?>"><a href="<?php echo e(route('sells.search')); ?>"><i class="fa fa-circle-o"></i> New Sell</a></li>
                    <li class="<?php echo e(isActiveRoute('sells.index')); ?>"><a href="<?php echo e(route('sells.index')); ?>"><i class="fa fa-circle-o"></i> View All Sales</a></li>
                    <li class="<?php echo e(isActiveRoute('currentmonth.sell')); ?>"><a href="<?php echo e(route('currentmonth.sell')); ?>"><i class="fa fa-circle-o"></i> Current Month Sales</a></li>
                    <li class="<?php echo e(isActiveRoute('searchMonthRange.sell')); ?>"><a href="<?php echo e(route('searchMonthRange.sell')); ?>"><i class="fa fa-circle-o"></i> Search Monthly Sale</a></li>
                </ul>
            </li>
            <li class="<?php echo e(isActiveRoute('suppliers.index')); ?>">
                <a href="<?php echo e(route('suppliers.index')); ?>"> <i class="fa fa-laptop"></i> <span>Suppliers</span></a>
            </li>

            <li class="<?php echo e(isActiveRoute('expenses.index')); ?>">
                <a href="<?php echo e(route('expenses.index')); ?>"> <i class="fa fa-dashboard"></i> <span>Expenses</span></a>
            </li>
            <li class="treeview <?php echo e(areActiveRoutes(['sellsReport', 'expenseReport', 'sellsVsexpenseReport'])); ?>">
                <a href="#">
                    <i class="fa fa-bar-chart"></i> <span>Reports</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(isActiveRoute('sellsReport')); ?>"><a href="<?php echo e(route('sellsReport')); ?>"><i class="fa fa-circle-o"></i> Sells</a></li>
                    <li class="<?php echo e(isActiveRoute('expenseReport')); ?>"><a href="<?php echo e(route('expenseReport')); ?>"><i class="fa fa-circle-o"></i> Expense</a></li>
                    <li class="<?php echo e(isActiveRoute('sellsVsexpenseReport')); ?>"><a href="<?php echo e(route('sellsVsexpenseReport')); ?>"><i class="fa fa-circle-o"></i> Sells vs Expense</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(areActiveRoutes(['users.create', 'users.index', ])); ?>">
                <a href="#">
                    <i class="fa fa-table"></i> <span>Users</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(isActiveRoute('users.create')); ?>"><a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-circle-o"></i>
                            New</a></li>
                    <li class="<?php echo e(isActiveRoute('users.index')); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-circle-o"></i> All Users</a></li>
                </ul>
            </li>

            <?php endif; ?>


            <?php if(\Cartalyst\Sentinel\Laravel\Facades\Sentinel::check() && \Cartalyst\Sentinel\Laravel\Facades\Sentinel::getUser()->roles()->first()->slug == 'manager'): ?>


                <li class="treeview <?php echo e(areActiveRoutes(['sells.search', 'sells.index', 'currentmonth.sell', 'searchMonthRange.sell'])); ?>">
                    <a href="#">
                        <i class="fa fa-pie-chart"></i>
                        <span>Sells</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php echo e(isActiveRoute('sells.search')); ?>"><a href="<?php echo e(route('sells.search')); ?>"><i class="fa fa-circle-o"></i> New Sell</a></li>
                        <li class="<?php echo e(isActiveRoute('sells.index')); ?>"><a href="<?php echo e(route('sells.index')); ?>"><i class="fa fa-circle-o"></i> View All Sales</a></li>
                    </ul>
                </li>

            <?php endif; ?>


            
                
                    
                    
                  
                  
                
                
            
            
                
                    
                    
                  
                  
                  
                
                
            
            
                
                    
                    
                  
                
                
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                
            
            
                
                    
                    
                  
                
                
                
                    
                    
                        
                            
                      
                    
                        
                        
                            
                            
                                
                                    
                          
                        
                                
                                
                                    
                                    
                                
                            
                        
                    
                    
                
            
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>