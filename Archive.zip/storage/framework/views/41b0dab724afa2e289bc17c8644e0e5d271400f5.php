<?php $__env->startSection('title'); ?>
    Current Month Sells
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Current Month Sells</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Current Month Sells</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">


                <div class="col-md-12">
                    <div class="row">
                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-aqua">
                                <div class="inner">
                                    <h3><?php echo e(count($sells)); ?></h3>

                                    <p>Sales</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                    <h3><?php echo e($customers); ?></h3>

                                    <p>New Customers</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-red" style="background: #605ca8 !important;">
                                <div class="inner">
                                    <h3><?php echo e($sum_amount); ?> Tk</h3>

                                    <p>Total Amount of Sell</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-green" style="background-color: #D81B60 !important;">
                                <div class="inner">
                                    <h3><?php echo e($expenses); ?></h3>

                                    <p>Tk Expenses</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-stats-bars"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box <?php if(($sum_amount - $profit_buying_price - $expenses) < 0): ?>bg-red
<?php else: ?> bg-green <?php endif; ?> ">
                                <div class="inner">
                                    <h3><?php echo e($sum_amount - $profit_buying_price - $expenses); ?></h3>

                                    <p>Tk Profit</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-stats-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Current Month Sells</h3>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($sells): ?>
                        <!-- /.box-header -->
                            <div class="box-body table-responsive no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Date</th>
                                        <th>Invoice No</th>
                                        <th>Stock</th>
                                        <th>Customer Name</th>
                                        <th>Product Name</th>
                                        <th>Color</th>
                                        <th>Code</th>
                                        <th>Qty</th>
                                        <th>Discount</th>
                                        <th>Due</th>
                                        <th>Total Amount</th>
                                        <th>Gifts</th>
                                        <th>Sold By</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr>

                                            <td><?php echo e($i); ?></td>

                                            <td>
                                                <?php if(\Carbon\Carbon::parse($sell->created_at)->format('d M Y') == \Carbon\Carbon::now()->format('d M Y')): ?>
                                                    <?php echo e(\Carbon\Carbon::parse($sell->created_at)->diffForHumans()); ?>

                                                <?php else: ?>
                                                    <?php echo e(\Carbon\Carbon::parse($sell->created_at)->format('d M Y')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($sell->invoice_no); ?></td>

                                            <td><?php if($sell->stock): ?>MGSE-<?php echo e($sell->stock->stockin_id); ?> <?php else: ?> --
                                                <?php endif; ?></td>

                                            <td><?php echo e($sell->customer->name); ?></td>

                                            <td><?php if($sell->stock): ?> <?php echo e($sell->stock->product->name); ?> <?php else: ?> --
                                                <?php endif; ?></td>
                                            <td><?php if($sell->stock): ?> <?php echo e($sell->stock->color); ?> <?php else: ?> -- <?php endif; ?></td>
                                            <td>
                                                <?php if($sell->imei): ?>
                                                    <?php echo e($sell->imei->imei); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($sell->quantity); ?></td>
                                            <td><?php echo e($sell->discount); ?></td>
                                            <td style="color:#ff2222"><b><?php echo e($sell->due); ?></b></td>
                                            <td><?php echo e($sell->total_amount); ?></td>
                                            <td>
                                                <?php if($sell->gifts): ?>
                                                    <?php echo e($sell->gifts); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($sell->user): ?>
                                                    <?php echo e($sell->user->name); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <a href="">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>


                                                <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['SellsController@destroy', $sell->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($sell->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>