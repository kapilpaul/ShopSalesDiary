<?php $__env->startSection('title'); ?>
    Suppliers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top_css'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Suppliers</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Suppliers</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-4">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add Suppliers</h3>
                        </div>
                        <!-- /.box-header -->


                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="box-body">
                                <div class="alert alert-error">
                                    <p><?php echo e(session('error')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo Form::open(['method' => 'POST', 'action' => 'SuppliersController@store', 'class' => '']); ?>

                        <div class="box-body">
                            <div class="form-group has-feedback">
                                <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder' => 'Supplier Name']); ?>


                                <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('name', 'Supplier Name Required')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group has-feedback">
                                <?php echo Form::text('phone_no', null, ['class'=>'form-control', 'placeholder' => 'Phone No']); ?>


                                <i class="fa fa-mobile form-control-feedback"></i>
                                <?php if($errors->has('phone_no')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('phone_no', 'Phone No Required')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group has-feedback">
                                <?php echo Form::text('address', null, ['class'=>'form-control', 'placeholder' => 'Address']); ?>


                                <i class="fa fa-map-marker form-control-feedback"></i>
                            </div>


                            <div class="form-group">
                                <?php echo Form::select('brand_id[]', $brands , null, ['class'=>'form-control select2', 'multiple'=>true, 'data-placeholder' => 'Select Brands' , 'style' => 'width: 100%;',]); ?>


                                <?php if($errors->has('brand_id')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('brand_id')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="box-footer">
                            <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                            <?php echo Form::submit('Add Supplier', ['class'=>'btn btn-info pull-right']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    </div>
                </div>

                <div class="col-md-8">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">All Suppliers</h3>
                        </div>

                        <?php if(session('cat_success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('cat_success')); ?></p>
                                </div>
                            </div>
                    <?php endif; ?>

                        <?php if($suppliers): ?>
                        <!-- /.box-header -->

                        <div class="box-body no-padding category_table">

                            <?php if(session('delete_success')): ?>
                                <div class="box-body">
                                    <div class="alert alert-success">
                                        <p><?php echo e(session('delete_success')); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Name</th>
                                        <th>Phone No</th>
                                        <th>Address</th>
                                        <th>Brand(s)</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                        <?php $i= 0;?>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++ ;?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($supplier->name); ?></td>
                                        <td><?php echo e($supplier->phone_no); ?></td>
                                        <td><?php echo e($supplier->address); ?></td>
                                        <td>
                                            <?php
                                                $j=0;
                                                foreach($supplier->brands as $brandName){
                                                    $coma = ($j>0)? ' / ':'';
                                                    echo $coma.$brandName->name;
                                                    $j++;
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('suppliers.edit', $supplier->id)); ?>">
                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                    data-original-title="Edit">

                                                    <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                        <span class="glyphicon glyphicon-pencil"></span>
                                                    </button>

                                            </p></a>
                                        </td>

                                        <td>


                                            <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['SuppliersController@destroy', $supplier->id]]); ?>

                                            <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                    <span class="glyphicon glyphicon-trash"></span>
                                                </button>
                                            </p>
                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                        <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($suppliers->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top_javascript'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('libs/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2()
        })
    </script>

    <script src="<?php echo e(asset('libs/plugins/upload_preview/jquery.uploadPreview.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $.uploadPreview({
                input_field: "#image-upload",   // Default: .image-upload
                preview_box: "#image-preview",  // Default: .image-preview
                label_field: "#image-label",    // Default: .image-label
                label_default: "Choose File",   // Default: Choose File
                label_selected: "Change File",  // Default: Change File
                no_label: false                 // Default: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>