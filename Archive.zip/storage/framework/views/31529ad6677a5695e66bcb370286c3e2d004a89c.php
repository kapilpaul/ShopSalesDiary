<?php $__env->startSection('title'); ?>
    Stocks
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Stocks</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Stocks</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">All Stocks</h3>
                            <div class="box-tools">

                                <?php echo Form::open(['method' => 'GET', 'action' => 'StockController@postDataSearch']); ?>

                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <?php echo Form::text('table_search', null, ['class'=>'form-control  pull-right', 'placeholder' => 'Search']); ?>

                                    <div class="input-group-btn">
                                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($stocks): ?>
                        <!-- /.box-header -->

                            <div class="box-body no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th style="width: 70px">Date</th>
                                        <th>Stock ID</th>
                                        <th style="width: 150px">Image</th>
                                        <th>Name</th>
                                        <th>Color</th>
                                        <th>Quantity</th>
                                        <th>IMEIS</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Buying Price</th>
                                        <th>Selling Price</th>
                                        <th>Profit</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Short List</th>
                                        <th>Stock Added By</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr <?php if($stock->stock_left == null): ?> style="background-color: #ddd" <?php endif; ?>>
                                            <td><?php echo e($i); ?></td>

                                            <td><?php echo e(Carbon\Carbon::parse($stock->created_at)->format('d-m-y h:i A')); ?></td>
                                            <td>MGSE-<?php echo e($stock->stockin_id); ?></td>
                                            <td>
                                                <?php if($stock->product): ?>
                                                    <?php if($stock->product->photo): ?>
                                                        <img class="img-thumbnail product-image" src="<?php echo e($stock->product->photo->photo); ?>" alt="">
                                                    <?php else: ?>
                                                        No Image
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($stock->product): ?>
                                                    <?php echo e($stock->product->name); ?>

                                                <?php else: ?> -- <?php endif; ?>
                                            </td>
                                            <td><?php echo e($stock->color); ?></td>
                                            <td><?php echo e($stock->quantity); ?></td>
                                            <td><a href="<?php echo e(route('stock.imeis', $stock->id)); ?>">IMEIS </a></td>
                                            <td>
                                                <?php if($stock->product): ?>
                                                    <?php if($stock->product->brand): ?>
                                                        <?php echo e($stock->product->brand->name); ?>

                                                    <?php else: ?> -- <?php endif; ?>
                                                <?php else: ?> -- <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($stock->product): ?>
                                                    <?php echo e($stock->product->category->name); ?>

                                                <?php else: ?> -- <?php endif; ?>
                                            </td>
                                            <td><?php echo e($stock->buying_price); ?></td>
                                            <td><?php echo e($stock->selling_price); ?></td>
                                            <td><?php echo e($stock->selling_price - $stock->buying_price); ?></td>
                                            <td><?php echo e($stock->paid); ?></td>
                                            <td><?php echo e($stock->due); ?></td>
                                            <td><?php if($stock->short_list): ?> <?php echo e($stock->short_list); ?> <?php else: ?> -- <?php endif; ?></td>
                                            <td><?php echo e($stock->user->name); ?></td>

                                            <td>
                                                <a href="<?php echo e(route('stocks.edit', $stock->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>


                                                <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['StockController@destroy', $stock->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($stocks->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>