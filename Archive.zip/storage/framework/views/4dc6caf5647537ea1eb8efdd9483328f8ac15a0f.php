<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>


<?php $__env->startSection('top_css'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Products</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Products</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">All Products</h3>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($products): ?>
                        <!-- /.box-header -->
                            <?php if($page_count > 0): ?>
                                <div class="box-body">
                                    <p class="text-aqua">Showing <?php echo e($products->count()); ?> of <?php echo e($products->total()); ?>

                                        Products </p>
                                </div>
                            <?php endif; ?>

                            <div class="box-body no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th style="width: 150px">Image</th>
                                        <th>Name</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>
                                                <?php if($product->photo): ?>
                                                <img src="<?php echo e(env('APP_URL')); ?><?php echo e($product->photo->photo); ?>" alt="" class="img-thumbnail product-image">
                                                <?php else: ?>
                                                    No Image Found
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td>
                                                <?php if($product->brand): ?>
                                                    <a href="<?php echo e($product->brand->slug); ?>"><?php echo e($product->brand->name); ?></a>
                                                <?php else: ?>
                                                    No Brand Selected
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($product->category): ?>
                                                    <a href="<?php echo e($product->category->id); ?>"><?php echo e($product->category->name); ?></a>
                                                <?php else: ?>
                                                    uncategorized
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>


                                                <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['ProductsController@destroy', $product->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($products->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>