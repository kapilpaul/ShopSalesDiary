<?php $__env->startSection('title'); ?>
    Stocks
<?php $__env->stopSection(); ?>


<?php $__env->startSection('top_css'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>New Stocks</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Stocks</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <?php if(session('success')): ?>
                    <div class="box-body">
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="box-body">
                        <div class="alert alert-error">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title pull-left">Edit IMEI</h3>
                        </div>
                        <!-- /.box-header -->

                        <?php if(count($errors)>0): ?>
                            <div class="col-lg-12">
                                <span class="row help-block">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3">
                                        <p class="text-red">* <?php echo e($error); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            </div>
                        <?php endif; ?>



                        <?php echo Form::model($productIMEI, ['method' => 'POST', 'action' => ['imeiController@update',
                        $productIMEI->id],  'class' =>  'two_col_forms']); ?>


                        <div class="row">
                            <div class="col-lg-12">
                                <div class="box-body">
                                    <div class="form-group">

                                        <?php echo Form::label('IMEI'); ?>


                                        <?php echo Form::text('imei', null, ['class'=>'form-control', 'placeholder' => 'IMEI']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-12">
                                <div class="box-footer">
                                    <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                                    <?php echo Form::submit('Add Stock', ['class'=>'btn btn-info pull-right']); ?>

                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>