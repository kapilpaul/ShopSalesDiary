<?php $__env->startSection('title'); ?>
    Sells
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Sells</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Sells</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

                <?php if(session('success')): ?>
                    <div class="box-body">
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="box-body">
                        <div class="alert alert-error">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-12">

                    <div class="box box-default collapsed-box">
                        <div class="box-header with-border" data-widget="collapse">
                            <h3 class="box-title">Search</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool"><i class="fa fa-plus"></i>
                                </button>
                            </div>
                            <!-- /.box-tools -->
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <?php echo Form::open(['method' => 'POST', 'action' => 'SellsController@searchingSells', 'class' =>
                            '']); ?>


                                <?php echo Form::label('Customer Phone No or Invoice No *'); ?>

                                <div class="input-group input-group-md">
                                    <?php echo Form::text('search_no', null, ['class'=>'form-control', 'placeholder' =>
                                    'Customer Phone No or Invoice No']); ?>

                                    <span class="input-group-btn">
                                        <?php echo Form::submit('Search', ['class'=>'btn btn-info btn-flat']); ?>

                                    </span>
                                </div>
                                <?php if($errors->has('search_no')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('search_no', 'Please Enter Phone
                                        No/Invoice Number')); ?></p>
                                    </span>
                                <?php endif; ?>

                            <?php echo Form::close(); ?>

                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">All Sells</h3>
                        </div>

                        <?php if($sells): ?>
                        <!-- /.box-header -->

                            <div class="box-body no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Date</th>
                                        <th>Invoice No</th>
                                        <th>Stock</th>
                                        <th>Customer Name</th>
                                        <th>Product Name</th>
                                        <th>Color</th>
                                        <th>Code</th>
                                        <th>Qty</th>
                                        <th>Discount</th>
                                        <th style="color: #ff2222;">Due</th>
                                        <th>Total Amount</th>
                                        <th>Gifts</th>
                                        <th>Sold By</th>
                                        <th style="width: 20px">Invoice</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>

                                            <td>
                                                <?php if(\Carbon\Carbon::parse($sell->created_at)->format('d M Y') == \Carbon\Carbon::now()->format('d M Y')): ?>
                                                    <?php echo e(\Carbon\Carbon::parse($sell->created_at)->diffForHumans()); ?>

                                                <?php else: ?>
                                                    <?php echo e(\Carbon\Carbon::parse($sell->created_at)->format('d M Y')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($sell->invoice_no); ?></td>

                                            <td><?php if($sell->stock): ?>MGSE-<?php echo e($sell->stock->stockin_id); ?> <?php else: ?> --
                                                <?php endif; ?></td>

                                            <td><?php echo e($sell->customer->name); ?></td>

                                            <td><?php if($sell->stock): ?> <?php echo e($sell->stock->product->name); ?> <?php else: ?> --
                                                <?php endif; ?></td>
                                            <td><?php if($sell->stock): ?> <?php echo e($sell->stock->color); ?> <?php else: ?> -- <?php endif; ?></td>
                                            <td>
                                                <?php if($sell->imei): ?>
                                                    <?php echo e($sell->imei->imei); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($sell->quantity); ?></td>
                                            <td><?php echo e($sell->discount); ?></td>
                                            <td style="color:#ff2222"><b><?php echo e($sell->due); ?></b></td>
                                            <td><?php echo e($sell->total_amount); ?></td>
                                            <td>
                                                <?php if($sell->gifts): ?>
                                                    <?php echo e($sell->gifts); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($sell->user): ?>
                                                    <?php echo e($sell->user->name); ?>

                                                <?php else: ?>
                                                    --
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <a href="<?php echo e(route('sells.invoice', $sell->invoice_no)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Invoice">

                                                        <button class="btn btn-primary btn-xs" data-title="Invoice" data-toggle="modal" data-target="#edit">
                                                            <i class="fa fa-print" style="font-size: 17px;"></i>

                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>
                                                <a href="<?php echo e(route('sells.edit', $sell->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>


                                                <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['SellsController@destroy', $sell->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($sells->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>