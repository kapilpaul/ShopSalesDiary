<?php $__env->startSection('title'); ?>
    Available Stocks
<?php $__env->stopSection(); ?>


<?php $__env->startSection('top_css'); ?>

    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Available Stocks</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Available Stocks</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <?php if($total_amount): ?>
                    <div class="col-lg-4 col-xs-6">
                        <!-- small box -->
                        <div class="small-box bg-red">
                            <div class="inner">
                                <h3><?php echo e($total_amount); ?> Tk</h3>

                                <p>Total Amount of Stock</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">All Stocks</h3>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>



                        <?php if($stocks): ?>
                        <!-- /.box-header -->

                            <div class="box-body category_table">
                                <table id="data_stock" class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Stock ID</th>
										<th style="width: 150px">Image</th>
                                        <th>Name</th>
                                        <th>IMEIS</th>
                                        <th>Color</th>
                                        <th>Available</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Buying Price</th>
                                        <th>Selling Price</th>
                                        <th>Profit</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr <?php if($stock->stock_left == null): ?> style="background-color: #ddd" <?php endif; ?>>
                                            <td><?php echo e($i); ?></td>

                                            <td>#<?php echo e($stock->stockin_id); ?></td>
											
                                            <td>
                                                <?php if($stock->product->photo): ?>
                                                    <img class="img-thumbnail product-image" src="<?php echo e($stock->product->photo->photo); ?>" alt="">
                                                <?php else: ?>
                                                    No Image
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($stock->product->name); ?></td>
                                            <td><a href="<?php echo e(route('stock.imeis', $stock->id)); ?>">IMEIS</a></td>
                                            <td><?php if($stock->color): ?> <?php echo e($stock->color); ?> <?php else: ?> -- <?php endif; ?></td>
                                            <td><?php echo e($stock->stock_left); ?></td>
                                            <td><?php echo e($stock->product->brand->name); ?></td>
                                            <td><?php echo e($stock->product->category->name); ?></td>
                                            <td><?php echo e($stock->buying_price); ?></td>
                                            <td><?php echo e($stock->selling_price); ?></td>
                                            <td><?php echo e($stock->selling_price - $stock->buying_price); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->

                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('top_javascript'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('libs/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(function () {
            $('#data_stock').DataTable()
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>