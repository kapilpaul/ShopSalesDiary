<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Categories</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Categories</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">All Categories</h3>

                            <div class="box-tools">
                                <a class="restore" href="<?php echo e(route('restoreallCategory')); ?>">Restore all category</a>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Name</th>
                                    <th style="width: 20px">Edit</th>
                                    <th style="width: 20px">Delete</th>
                                </tr>
                                <?php if($categories): ?>
                                    <?php $i=0;?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++;?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('category.edit', $category->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>
                                            <td>


                                                <?php echo Form::open(['method' => 'POST', 'class' =>'user_delete pull-left', 'action' => ['CategoryController@restore', $category->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button class="btn btn-danger btn-xs" data-title="Restore" data-toggle="modal" data-target="#delete">
                                                        <i class="fa fa-undo" aria-hidden="true"></i> Restore
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>No Categories</td>
                                        <td>No Categories</td>
                                        <td>No Categories</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($categories->links('layouts.pagination')); ?>

                        <?php endif; ?>
                    </div>
                    <!-- /.box -->
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>


    <script type="text/javascript">
        $(window).on('load', function() {
            setTimeout(function(){ $('.alert-success, .alert-danger').slideUp() }, 5000);
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>