<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>


<?php $__env->startSection('top_css'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>New Products</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Products</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <?php if(session('success')): ?>
                    <div class="box-body">
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="box-body">
                        <div class="alert alert-error">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-8">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add Products</h3>
                        </div>
                        <!-- /.box-header -->

                        <?php echo Form::open(['method' => 'POST', 'action' => 'ProductsController@store', 'class' => '', 'files' => true]); ?>

                            <div class="box-body">
                                <div class="form-group has-feedback">
                                    <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder' => 'Product Name']); ?>


                                    <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('name', 'Category Name Required')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::select('brand_id', $brands, null, ['class'=>'form-control select2', 'placeholder' => 'Pick a Brand...' , 'style' => 'width: 100%;']); ?>


                                    <?php if($errors->has('brand_id')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('brand_id')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::select('category_id', $category, null, ['class'=>'form-control select2', 'placeholder' => 'Pick a Category...' , 'style' => 'width: 100%;']); ?>


                                    <?php if($errors->has('category_id')): ?>
                                        <span class="help-block">
                                            <p class="text-red"><?php echo e($errors->first('category_id')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                        <div class="box-footer">
                            <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                            <?php echo Form::submit('Add Product', ['class'=>'btn btn-info pull-right']); ?>

                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="box box-info">
                        <div class="box-header text-center with-border">
                            <h3 class="box-title">Add Product Image</h3>
                        </div>
                        <div class="box-body">

                            <div id="image-preview">
                                <div class="">
                                    <label for="image-upload" id="image-label">Choose Image</label>
                                    <?php echo Form::file('photo_id', ['id' => 'image-upload']); ?>

                                </div>
                            </div>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top_javascript'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('libs/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2()
        })
    </script>

    <script src="<?php echo e(asset('libs/plugins/upload_preview/jquery.uploadPreview.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $.uploadPreview({
                input_field: "#image-upload",   // Default: .image-upload
                preview_box: "#image-preview",  // Default: .image-preview
                label_field: "#image-label",    // Default: .image-label
                label_default: "Choose File",   // Default: Choose File
                label_selected: "Change File",  // Default: Change File
                no_label: false                 // Default: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>