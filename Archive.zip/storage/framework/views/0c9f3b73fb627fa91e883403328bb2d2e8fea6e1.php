<?php $__env->startSection('title'); ?>
    Forgot Password
<?php $__env->stopSection(); ?>



<?php $__env->startSection('body_content'); ?>
    <body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href=""><b>Mobile</b> Garden</a>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body" style="overflow: hidden;">
            <p class="login-box-msg">Forgot your password</p>

            <?php echo Form::open(['method' => 'POST', 'action' => 'ForgetPasswordController@postForgotPassword']); ?>


            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e(session('error')); ?></p>
                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>

                <div class="form-group has-feedback">
                    <?php echo Form::email('email', null, ['class'=>'form-control', 'placeholder' => 'example@example.com']); ?>

                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <p class="text-red"><?php echo e($errors->first('email')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>


                <div class="col-xs-4 pull-right">
                    <?php echo Form::submit('Send', ['class'=>'btn btn-primary btn-block btn-flat']); ?>

                </div>

            <?php echo Form::close(); ?>

        </div>
        <!-- /.form-box -->
    </div>
    <!-- /.register-box -->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('javascripts'); ?>
        <!-- iCheck -->
        <script src="<?php echo e(asset('libs/plugins/iCheck/icheck.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.loginRegister', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>