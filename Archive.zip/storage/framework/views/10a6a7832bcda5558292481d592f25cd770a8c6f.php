<?php $__env->startSection('title'); ?>
    Brands
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Brands</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Brands</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add Brand</h3>
                        </div>
                        <!-- /.box-header -->


                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="box-body">
                                <div class="alert alert-error">
                                    <p><?php echo e(session('error')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo Form::open(['method' => 'POST', 'action' => 'BrandsController@store', 'class' => '']); ?>

                        <div class="box-body">
                            <div class="form-group has-feedback">
                                <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder' => 'Brand Name']); ?>


                                <span class="glyphicon glyphicon-tree-conifer form-control-feedback"></span>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <p class="text-red"><?php echo e($errors->first('name', 'Brand Name Required')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="box-footer">
                            <?php echo Form::reset('Cancel', ['class'=>'btn btn-default']); ?>

                            <?php echo Form::submit('Add Brand', ['class'=>'btn btn-info pull-right']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    </div>
                </div>

                <div class="col-md-6">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">All Brands</h3>
                        </div>

                        <?php if(session('cat_success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('cat_success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($brands): ?>
                        <!-- /.box-header -->

                        <div class="box-body no-padding category_table">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Name</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                        <?php $i= 0;?>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++ ;?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($brand->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('brands.edit', $brand->id)); ?>">
                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Edit">

                                                    <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                        <span class="glyphicon glyphicon-pencil"></span>
                                                    </button>

                                            </p></a>
                                        </td>

                                        <td>


                                            <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['BrandsController@destroy', $brand->id]]); ?>

                                            <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                    <span class="glyphicon glyphicon-trash"></span>
                                                </button>
                                            </p>
                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                        <!-- /.box-body -->
                        <?php if($page_count > 0): ?>
                            <?php echo e($brands->links('layouts.pagination')); ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>