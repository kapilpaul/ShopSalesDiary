<?php $__env->startSection('title'); ?>
    IMEIS
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>IMEIS</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Stocks</a></li>
                <li><a href="#">IMEIS</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">IMEI No in Stock
                            </h3>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="box-body">
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($imeis): ?>
                        <!-- /.box-header -->

                            <div class="box-body no-padding category_table">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Stock ID</th>
                                        <th>IMEI</th>
                                        <th>Color</th>
                                        <th>Product Name</th>
                                        <th>Brand</th>
                                        <th style="width: 20px">Edit</th>
                                        <th style="width: 20px">Delete</th>
                                    </tr>

                                    <?php $i= 0;?>
                                    <?php $__currentLoopData = $imeis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imei): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++ ;?>
                                        <tr <?php if($imei->sold == 1): ?> style="color: #d33724" <?php endif; ?>>
                                            <td><?php echo e($i); ?></td>


                                            <td>MGSE-<?php echo e($imei->stock->stockin_id); ?></td>

                                            <td><?php echo e($imei->imei); ?> <?php if($imei->sold == 1): ?><i class="fa fa-times-circle-o" aria-hidden="true"></i><?php endif; ?></td>
                                            <td><?php echo e($imei->stock->color); ?></td>
                                            <td><?php echo e($imei->stock->product->name); ?></td>
                                            <td><?php echo e($imei->stock->product->brand->name); ?></td>

                                            <td>
                                                <a href="<?php echo e(route('imei.edit', $imei->id)); ?>">
                                                    <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title=""
                                                       data-original-title="Edit">

                                                        <button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit">
                                                            <span class="glyphicon glyphicon-pencil"></span>
                                                        </button>

                                                    </p></a>
                                            </td>

                                            <td>


                                                <?php echo Form::open(['method' => 'DELETE', 'class' =>'user_delete pull-left', 'action' => ['StockController@destroy', $imei->id]]); ?>

                                                <p class="no_bottom_margin" data-placement="top" data-toggle="tooltip" title="" data-original-title="Delete">
                                                    <button onclick="alert('Are You Sure You Want To Delete')" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>
                                                </p>
                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <!-- /.box-body -->


                    </div>
                </div>
            </div>
            <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>