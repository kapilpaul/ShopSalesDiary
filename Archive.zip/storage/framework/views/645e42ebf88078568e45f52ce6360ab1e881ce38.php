<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Dashboard
                <small>Version 2.0</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Dashboard</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Main row -->
            <div class="row">
                <!-- Left col -->
                <div class="col-md-8">


                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title">Branded Product Sell</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="chart-responsive">
                                        <canvas id="pieChart" height="150"></canvas>
                                    </div>
                                    <!-- ./chart-responsive -->
                                </div>
                                <!-- /.col -->
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.box-body -->
                    </div>

                    <?php if($latest_sales): ?>
                    <!-- TABLE: LATEST ORDERS -->
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Latest Orders</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                    <tr>
                                        <th>Invoice No</th>
                                        <th>Item</th>
                                        <th>Customer Name</th>
                                        <th>Total Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $latest_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>MGSIT-<?php echo e($latest_sale->invoice_no); ?></td>
                                            <td><?php if($latest_sale->stock): ?> <?php echo e($latest_sale->stock->product->name); ?>

                                                <?php else: ?> -- <?php endif; ?></td>
                                            <td><?php echo e($latest_sale->customer->name); ?></td>
                                            <td><?php echo e($latest_sale->total_amount); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer clearfix">
                            <a href="<?php echo e(route('sells.index')); ?>" class="btn btn-sm btn-default btn-flat
                            pull-right">View All</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /.box -->
                        <?php endif; ?>
                </div>
                <!-- /.col -->

                <div class="col-md-4">

                    <?php if($stocks): ?>

                    <!-- PRODUCT LIST -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recently Added Products Stocks</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <ul class="products-list product-list-in-box">
                                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="item">
                                    <div class="product-img">
                                        <?php if($stock->product->photo): ?>
                                            <img class="img-thumbnail product-image" src="<?php echo e(env('APP_URL')); ?><?php echo e($stock->product->photo->photo); ?>" alt="">
                                        <?php else: ?>
                                            <img src="img/default-50x50.gif" alt="<?php echo e($stock->product->name); ?>">
                                        <?php endif; ?>

                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title"><?php echo e($stock->product->name); ?> <?php if($stock->color): ?>(<?php echo e($stock->color); ?>) <?php endif; ?>
                                            <span class="label label-warning pull-right">Tk. <?php echo e($stock->selling_price); ?></span></a>
                                        <span class="product-description">
                                            <?php echo e($stock->stock_left); ?> in stock
                                        </span>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- /.item -->
                            </ul>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-center">
                            <a href="<?php echo e(route('stocks.index')); ?>" class="uppercase">View All Products</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /.box -->

                        <?php endif; ?>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
    <script>
        $(function () {

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieChart       = new Chart(pieChartCanvas)
    var PieData        = [
      <?php if($brand_sell_count): ?>
            <?php $__currentLoopData = $brand_sell_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
        value    : '<?php echo e(count($brand_count)); ?>',
        color    : '<?php echo e(random_color()); ?>',
        label    : '<?php
//
                        foreach($brand_count as $name){
                            echo $name->name;
                            break;
                        }?>'
      },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    ]

    var pieOptions     = {
      //Boolean - Whether we should show a stroke on each segment
      segmentShowStroke    : true,
      //String - The colour of each segment stroke
      segmentStrokeColor   : '#fff',
      //Number - The width of each segment stroke
      segmentStrokeWidth   : 2,
      //Number - The percentage of the chart that we cut out of the middle
      percentageInnerCutout: 50, // This is 0 for Pie charts
      //Number - Amount of animation steps
      animationSteps       : 100,
      //String - Animation easing effect
      animationEasing      : 'easeOutBounce',
      //Boolean - Whether we animate the rotation of the Doughnut
      animateRotate        : true,
      //Boolean - Whether we animate scaling the Doughnut from the centre
      animateScale         : false,
      //Boolean - whether to make the chart responsive to window resizing
      responsive           : true,
      // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio  : true,
      //String - A legend template
      legendTemplate       : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    pieChart.Doughnut(PieData, pieOptions)
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>